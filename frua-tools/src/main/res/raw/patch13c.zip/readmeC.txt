By J Varnes					Jul 25, 2009

Updated by nologgie (Tom Ward)	Jan 18, 2010
2nd Update by nologgie		Aug 14, 2010

This is a working / beta version of the unofficial FRUA v1.3 patch to fix various bugs and misc. errata.
This is version "C" (i.e. fruav13c) and will be superseded by a final version at a later date.

This file is intended to be used with UAShell. To use it, create a new design and place the included file labeled diff.tbl in that design then run UAShell and apply the design. UAShell will patch your CKIT.exe file with these changes while that design is being used.

The lines below list the various fixes and the associated lines in diff.tbl:

**********

Added Brian O'Donnell's "Pronoun" fix.
^ on its own still puts in the name of the active character, though I've
removed the limitation of 3 instances on a line. If the designer has a
reason for 4 or more then he should playtest the whole game, not just
this bit.

^1 puts in the name of another character. If the first character on the
list is not the active character, that's the one picked. Otherwise, it's
the second on the list. If a designer uses this in a solo game results
will be 'unspecified' - but probably unfortunate.

^2 puts in 'his/her', depending on the gender of the active character.
^3 does 'he/she' in the same way.
^4, as you might guess, does 'him/her'.
^5, ^6 and ^7, the pronouns for the 'other' character."

4E CD 0
4F 1 2
52 A0 0
53 1 2
56 8C 94
5A 5E 5F
66 E7 0
67 1 2
6A B9 99
6014 83 81
6016 4 58
6017 56 1
6018 FF 56
6019 76 16
601A E 8D
601B FF 86
601C 76 A8
601D C FE
601E FF 50
601F 4E 8B
6020 A F0
6024 50 48
6025 FF 50
6026 76 FF
6027 8 76
6028 FF 8
6029 76 FF
602A 6 76
602B 9A 6
602C 6E 9A
602D 4 6E
602E F0 4
602F C F0
6030 83 C
6031 C4 83
6032 A C4
6033 33 A
6034 F6 8B
6035 C4 DE
6036 5E 36
6037 C 8A
6038 8C 7
6039 46 3C
603A FE 5E
603B 89 75
603C 5E 60
603D FC 43
603E E9 36
603F 95 8A
6040 0 7
6042 5E 1E
6043 FC 29
6044 26 D1
6045 80 8B
6046 3F 16
6047 5E DD
6048 74 B3
6049 3 3B
604A E9 D3
604B 86 75
604C 0 3
604D 46 26
604E 8B C4
604F C6 1F
6050 3D 3C
6051 3 31
6052 0 75
6053 7D 1F
6054 7E 46
6055 FF 81
6056 76 C3
6057 FE 60
6058 53 0
6059 9A 6
605A 77 53
605B 25 FF
605C D7 76
605D 0 E
605E 59 FF
605F 59 76
6060 50 C
6061 8B 9A
6062 16 5E
6063 DF 25
6064 B3 D7
6065 A1 0
6066 DD 9A
6067 B3 77
6068 5 25
6069 60 D7
606B 52 83
606C 50 C4
606D 9A 8
606E 77 1
606F 25 46
6070 D7 C
6071 0 EB
6072 59 33
6073 59 3C
6074 8B 35
6075 4E 7C
6076 FE 16
6077 8B 3C
6078 5E 37
6079 FC 7F
607A 3 12
607B D8 46
607C 51 98
607D 53 D1
607E 8B E0
607F D1 26
6080 8B 2
6081 46 47
6082 FC 5C
6083 40 D1
6084 52 E0
6085 50 D1
6086 9A E0
6087 41 E
6088 27 4
6089 D7 38
608A 0 50
608B 83 EB
608C C4 CE
608D A C4
608E 8B 1E
608F 16 DD
6090 DF B3
6091 B3 3C
6092 A1 32
6093 DD 7C
6094 B3 C0
6095 5 3C
6096 60 34
6097 0 7F
6098 52 BC
6099 50 4
609A 9A 3
609B 77 EB
609C 25 DE
609D D7 C4
609E 0 5E
609F 59 C
60A0 59 26
60A1 50 88
60A2 FF 7
60A3 76 FF
60A4 FE 46
60A5 FF C
60A6 76 46
60A7 FC A
60A8 8B C0
60A9 16 75
60AA DF 89
60AB B3 5E
60AC A1 8B
60AD DD E5
60AE B3 5D
60AF 5 CB
60B0 60 68
60B1 0 69
60B2 52 73
60B3 50 0
60B4 9A 68
60B5 41 65
60B6 27 72
60B7 D7 0
60B8 0 68
60B9 83 65
60BA C4 0
60BB A 0
60BC 8B 73
60BD 16 68
60BE DF 65
60BF B3 0
60C0 A1 68
60C1 DD 69
60C2 B3 6D
60C3 5 0
60C4 60 68
60C5 0 65
60C6 52 72
60C7 50 0

**********

Added Brian O'Donnell's "Treasure 2 Pic Display" bug fix:

7CD1 1E C6
7CD2 B8 6
7CD3 22 61
7CD4 CA B7
7CD5 50 0
7CD6 B0 EB
7CD7 0 11

**********

Added Halfscan's "Death by Old Age" bug fix. When characters age past their max age they will die after combat (HP 0 and status changed to GONE). The following lines in the diff table apply to this fix:

1E608 74 72
1E609 7 0
1E642 3 2B
1E67B 3 2B

**********

Added "fix" for game always asks for password "bug". If you do not agree with this fix OR do not see this as a bug OR do not need / want this fix then remove the following line from the diff.tbl:

2C61D 74 EB

**********

Added Watcher05's dungeon 36 "Do-Only-Once" bug fix (This was designed to solve the problem in which the events tagged Do Only Once in dungeon module #36 will fail to fire at all. It will not fix that problem in grown dungeons i.e. GEO041-GEO255). The following lines in the diff table apply to this fix:

2E819 8B A1
2E81A 76 19
2E81B 6 67
2E81C 8B 3C
2E81D C6 0
2E81E 48 74
2E81F 8B 40
2E820 F0 48
2E821 A1 42
2E822 19 BA
2E823 67 64
2E824 BA 0
2E825 64 F7
2E826 0 E2
2E827 F7 3
2E828 E2 46
2E829 3 6
2E82A C6 48
2E873 8B A1
2E874 76 19
2E875 6 67
2E876 8B 3C
2E877 C6 0
2E878 48 74
2E879 8B 4B
2E87A F0 48
2E87B A1 42
2E87C 19 BA
2E87D 67 64
2E87E BA 0
2E87F 64 F7
2E880 0 E2
2E881 F7 3 
2E882 E2 46
2E883 3 6
2E884 C6 48
2E8D1 8B A1
2E8D2 76 19
2E8D3 6 67
2E8D4 8B 3C
2E8D5 C6 0
2E8D6 48 74
2E8D7 8B 53
2E8D8 F0 48
2E8D9 A1 42
2E8DA 19 BA
2E8DB 67 64
2E8DC BA 0
2E8DD 64 F7
2E8DE 0 E2
2E8DF F7 3
2E8E0 E2 46
2E8E1 3 6
2E8E2 C6 48

**********

Added Brian O'Donnell's fix to allow animated pics in text events. Previously the TEXT event would not animate pictures which had additional frames of animation. This line in the diff.tbl fixes this bug:

2F1B8 0 1

**********

Added Brian O'Donnell's River Combat code. This code allows the special river tiles to be displayed when the game draws combat maps. To use the River tiles while designing simply set the Auto Approach toggle to 'On' in a combat event. Note that like any combat map you must use careful wall placement to insure that there is ample space for the river to be displayed and of use. Also note that you don't have to only use the river wilderness. You can in fact use any WILD art and the "river" will be constructed from the special pieces in that template (which can create both interesting and bizarre results ;)
The following lines in the diff.tbl apply to this:

4256E 16 F
42578 7 5
4257E EB C4
4257F 5 5E
42580 C6 6
42581 6 26
42582 22 8A
42583 67 47
42584 0 C
42585 80 24
42586 3E 20
42587 E2 C4
42588 73 1E
42589 FF 5B
4258A 74 B7
4258B 3B 26
4258C 80 88
4258D 3E 47
4258E E2 33
4258F 73 A0
42590 1 E2
42591 75 73
42592 B 3C
42593 C4 FF
42594 1E 74
42595 5B 31
42596 B7 C4
42597 26 1E
42598 C6 5B
42599 47 B7
4259A 2E 26
4259B 1 C6
4259C EB 47
4259D 22 2E
4259E 80 0
4259F 3E 3C
425A0 E2 3
425A1 73 74
425A2 2 1D
425A3 75 26
425A4 B 0
425A5 C4 47
425A6 1E 2E
425A7 5B EB
425A8 B7 17

**********

Added David Knott's "Temple Rapid Healing" bug fix:

71D6C 14 1A

**********

Added Gender Strength Equality hack. (Same strength maximums for both genders of a given race.)

86035 10 12
86037 00 4B
86045 11 12
86047 00 5A
86055 11 12
86057 00 63
86065 0F 12
86067 00 32
86075 0E 11
86087 32 64

**********

Corrected the following saving throws:
 Corrected Cleric Level 19 saving throws (from 4/7/8/10/9 to 2/5/6/8/7 per DMG pg. 79)

 Corrected Fighter Level 0 saving throws (from 10/13/14/16/15 to 16/17/18/20/19 per DMG pg. 79)

 Corrected Paladin Level 0 saving throws (from 10/13/14/16/15 to 14/15/16/18/17 per DMG pg. 79 +2 as Paladins have +2 to all saving throws per PHB pg. 22)

 Corrected Paladin Level 5 & 6 saving throws (from 9/9/11/11/12 to 9/10/11/11/12 per DMG pg. 79 +2 as Paladins have +2 to all saving throws per PHB pg. 22)

 Corrected Ranger Level 0 saving throws (from 10/13/14/16/15 to 16/17/18/20/19 per DMG pg. 79)

 Corrected Magic-User Level 0 saving throws (from 10/13/14/16/15 to 14/13/11/15/12 same as level 1)

869D5 4 2
869D6 7 5
869D7 8 6
869D8 A 8
869D9 9 7
86A52 A 10
86A53 D 11
86A54 E 12
86A55 10 14
86A56 F 13
86AC0 A E
86AC1 D F
86AC2 E 10
86AC3 10 12
86AC4 F 11
86ADA 9 A
86ADF 9 A
86B2E A 10
86B2F D 11
86B30 E 12
86B31 10 14
86B32 F 13
86B9C A E
86B9E E B
86B9F 10 F
86BA0 F C

Filled in Thief Saving Throws table (which by default were incorrectly set to all zeros):

86C0A 0 D
86C0B 0 C
86C0C 0 E
86C0D 0 10
86C0E 0 F
86C0F 0 D
86C10 0 C
86C11 0 E
86C12 0 10
86C13 0 F
86C14 0 D
86C15 0 C
86C16 0 E
86C17 0 10
86C18 0 F
86C19 0 D
86C1A 0 C
86C1B 0 E
86C1C 0 10
86C1D 0 F
86C1E 0 D
86C1F 0 C
86C20 0 E
86C21 0 10
86C22 0 F
86C23 0 C
86C24 0 B
86C25 0 C
86C26 0 F
86C27 0 D
86C28 0 C
86C29 0 B
86C2A 0 C
86C2B 0 F
86C2C 0 D
86C2D 0 C
86C2E 0 B
86C2F 0 C
86C30 0 F
86C31 0 D
86C32 0 C
86C33 0 B
86C34 0 C
86C35 0 F
86C36 0 D
86C37 0 B
86C38 0 A
86C39 0 A
86C3A 0 E
86C3B 0 B
86C3C 0 B
86C3D 0 A
86C3E 0 A
86C3F 0 E
86C40 0 B
86C41 0 B
86C42 0 A
86C43 0 A
86C44 0 E
86C45 0 B
86C46 0 B
86C47 0 A
86C48 0 A
86C49 0 E
86C4A 0 B
86C4B 0 A
86C4C 0 9
86C4D 0 8
86C4E 0 D
86C4F 0 9
86C50 0 A
86C51 0 9
86C52 0 8
86C53 0 D
86C54 0 9
86C55 0 A
86C56 0 9
86C57 0 8
86C58 0 D
86C59 0 9
86C5A 0 A
86C5B 0 9
86C5C 0 8
86C5D 0 D
86C5E 0 9
86C5F 0 9
86C60 0 8
86C61 0 6
86C62 0 C
86C63 0 7
86C64 0 9
86C65 0 8
86C66 0 6
86C67 0 C
86C68 0 7
86C69 0 9
86C6A 0 8
86C6B 0 6
86C6C 0 C
86C6D 0 7
86C6E 0 9
86C6F 0 8
86C70 0 6
86C71 0 C
86C72 0 7
86C73 0 8
86C74 0 7
86C75 0 4
86C76 0 B
86C77 0 5

**********

Changed Power Word Blind to function based on current rather than maximum hit points.

586d8 81 8b
586d9 00 01
586e0 81 8b
586e1 00 01
586f3 81 8b
586f4 00 01
58751 81 8b
58752 00 01
58759 81 8b
5875a 00 01
5876c 81 8b
5876d 00 01

**********

Changed Power Word Kill to function based on current rather than maximum hit points.

58be9 81 8b
58bea 00 01
58bf1 81 8b
58bf2 00 01
58c60 81 8b
58c61 00 01

**********

Changed name display color on the character creation screen from black to light blue.

3D582 0 b

**********

Changed version and date on main screen.

89A8B 32 33
89A8C 20 63
89A92 20 41
89A93 20 75
89A94 4A 67
89A96 6E 73
89A97 65 74
89A99 32 31
89A9A 38 34
89A9C 31 32
89A9D 39 30
89A9E 39 31
89A9F 33 30

**********

All diff.tbl files should end with a single zero followed by a return as shown below.
0

